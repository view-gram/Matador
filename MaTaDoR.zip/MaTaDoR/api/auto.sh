#!/bin/bash
COUNTER=1
while(true) do
./matador.sh
let COUNTER=COUNTER+1 
done
